#set_attribute mmmc_cmds_in_lui true ;
# Flowkit v18.10-p005_1
##############################################################################
## LIBRARY SETS
##############################################################################
create_library_set \
    -name               PVT_1P08V_125C \
    -timing \
                        [list \
                            ${dataDir}/libs/GPDK045/gsclib045/timing/slow_vdd1v2_basicCells.lib \
	                    ${dataDir}/libs/macros/ram_256x16A_slow_syn.lib\
                            ${dataDir}/libs/macros/rom_512x16A_slow_syn.lib\
                            ${dataDir}/libs/macros/pllclk_slow.lib\
                        ]

create_library_set \
    -name               PVT_1P32V_0C \
    -timing \
                        [list \
                            ${dataDir}/libs/GPDK045/gsclib045/timing/fast_vdd1v2_basicCells.lib \
	                    ${dataDir}/libs/macros/ram_256x16A_slow_syn.lib\
                            ${dataDir}/libs/macros/rom_512x16A_slow_syn.lib\
                            ${dataDir}/libs/macros/pllclk_slow.lib\
                        ]

##############################################################################
## OPERATING CONDITIONS
##############################################################################
create_op_cond \
    -name               max \
    -library_file       ${dataDir}/libs/GPDK045/gsclib045/timing/slow_vdd1v2_basicCells.lib \
    -P                  1 \
    -V                  1.08 \
    -T                  125

create_op_cond \
    -name               min \
    -library_file       ${dataDir}/libs/GPDK045/gsclib045/timing/fast_vdd1v2_basicCells.lib \
    -P                  1 \
    -V                  1.32 \
    -T                  0

##############################################################################
## RC CORNERS
##############################################################################
create_rc_corner \
    -name               rc_max \
    -T                  125 \
    -qx_tech_file      ${dataDir}/libs/GPDK045/gsclib045_tech/voltus/tech_181/techonly.cl/gpdk045.tch

create_rc_corner \
    -name               rc_min \
    -T                  0 \
    -qx_tech_file      ${dataDir}/libs/GPDK045/gsclib045_tech/voltus/tech_181/techonly.cl/gpdk045.tch

##############################################################################
## DELAY CORNERS
##############################################################################
create_delay_corner \
    -name               slow_maxrc \
    -library_set        PVT_1P08V_125C \
    -opcond             max \
    -rc_corner          rc_max

create_delay_corner \
    -name               fast_minrc \
    -library_set        PVT_1P32V_0C \
    -opcond             min \
    -rc_corner          rc_min

##############################################################################
## CONSTRAINT MODES
##############################################################################
create_constraint_mode \
    -name               func \
    -sdc_files          [list \
                            ${dataDir}/sdc/dtmf_recvr_core_gate.sdc \
                        ]

##############################################################################
## ANALYSIS VIEWS
##############################################################################
create_analysis_view \
    -name               func-slow_maxrc \
    -constraint_mode    func \
    -delay_corner       slow_maxrc

create_analysis_view \
    -name               func-fast_minrc \
    -constraint_mode    func \
    -delay_corner       fast_minrc

##############################################################################
## ACTIVE VIEWS
##############################################################################
set_analysis_view \
    -setup              [list func-slow_maxrc] \
    -hold               [list func-slow_maxrc]
