create_library_set -name PVT_1P08V_125C\
   -timing\
    [list ${dataDir}/libs/GPDK045/gsclib045/timing/slow_vdd1v2_basicCells.lib\
    ${dataDir}/libs/macros/ram_256x16A_slow_syn.lib\
    ${dataDir}/libs/macros/rom_512x16A_slow_syn.lib\
    ${dataDir}/libs/macros/pllclk_slow.lib]
create_library_set -name PVT_1P32V_0C\
   -timing\
    [list ${dataDir}/libs/GPDK045/gsclib045/timing/fast_vdd1v2_basicCells.lib\
    ${dataDir}/libs/macros/ram_256x16A_slow_syn.lib\
    ${dataDir}/libs/macros/rom_512x16A_slow_syn.lib\
    ${dataDir}/libs/macros/pllclk_slow.lib]
create_opcond -name min -process 1 -voltage 1.32 -temperature 0
create_opcond -name max -process 1 -voltage 1.08 -temperature 125
create_timing_condition -name fast\
   -library_sets [list PVT_1P32V_0C]\
   -opcond min
create_timing_condition -name slow\
   -library_sets [list PVT_1P08V_125C]\
   -opcond max
create_rc_corner -name rc_min\
   -pre_route_res 1\
   -post_route_res {1 1 1}\
   -pre_route_cap 1\
   -post_route_cap {1 1 1}\
   -post_route_cross_cap {1 1 1}\
   -pre_route_clock_res 0\
   -pre_route_clock_cap 0\
   -post_route_clock_cap {1 1 1}\
   -post_route_clock_res {1 1 1}\
   -post_route_clock_cross_cap {1 1 1}\
   -temperature 0\
   -qrc_tech ${dataDir}/libs/GPDK045/gsclib045_tech/voltus/tech_181/techonly.cl/gpdk045.tch
create_rc_corner -name rc_max\
   -pre_route_res 1\
   -post_route_res {1 1 1}\
   -pre_route_cap 1\
   -post_route_cap {1 1 1}\
   -post_route_cross_cap {1 1 1}\
   -pre_route_clock_res 0\
   -pre_route_clock_cap 0\
   -post_route_clock_cap {1 1 1}\
   -post_route_clock_res {1 1 1}\
   -post_route_clock_cross_cap {1 1 1}\
   -temperature 125\
   -qrc_tech ${dataDir}/libs/GPDK045/gsclib045_tech/voltus/tech_181/techonly.cl/gpdk045.tch
create_delay_corner -name slow_maxrc\
   -early_timing_condition {slow}\
   -late_timing_condition {slow}\
   -rc_corner rc_max
create_delay_corner -name fast_minrc\
   -early_timing_condition {fast}\
   -late_timing_condition {fast}\
   -rc_corner rc_min
create_constraint_mode -name func\
   -sdc_files\
    [list ${dataDir}/sdc/dtmf_recvr_core_gate.sdc]
create_analysis_view -name func-slow_maxrc -constraint_mode func -delay_corner slow_maxrc
create_analysis_view -name func-fast_minrc -constraint_mode func -delay_corner fast_minrc
set_analysis_view -setup [list func-slow_maxrc] -hold [list func-slow_maxrc]
