# Flowkit v18.10-p005_1
##############################################################################
## LIBRARY SETS
##############################################################################
create_library_set \
    -name               PVT_1P08V_125C \
    -timing \
                        [list \
                            ${dataDir}/libs/GPDK045/gsclib045/timing/slow_vdd1v2_basicCells.lib \
	                    ${dataDir}/libs/macros/ram_256x16A_slow_syn.lib\
                            ${dataDir}/libs/macros/rom_512x16A_slow_syn.lib\
                            ${dataDir}/libs/macros/pllclk_slow.lib\
                        ]

create_library_set \
    -name               PVT_1P32V_0C \
    -timing \
                        [list \
                            ${dataDir}/libs/GPDK045/gsclib045/timing/fast_vdd1v2_basicCells.lib \
	                    ${dataDir}/libs/macros/ram_256x16A_slow_syn.lib\
                            ${dataDir}/libs/macros/rom_512x16A_slow_syn.lib\
                            ${dataDir}/libs/macros/pllclk_slow.lib\
                        ]
##############################################################################
## OPERATING CONDITIONS
##############################################################################
create_opcond \
    -name               max \
    -process            1 \
    -voltage            1.08 \
    -temperature        125

create_opcond \
    -name               min \
    -process            1 \
    -voltage            1.32 \
    -temperature        0

##############################################################################
## TIMING CONDITIONS
##############################################################################
create_timing_condition \
    -name               slow \
    -library_sets       [list PVT_1P08V_125C ] \
    -opcond             max

create_timing_condition \
    -name               fast \
    -library_sets       [list PVT_1P32V_0C ] \
    -opcond             min

##############################################################################
## RC CORNERS
##############################################################################
create_rc_corner \
    -name               rc_max \
    -temperature        125 \
    -qrc_tech           ${dataDir}/libs/GPDK045/gsclib045_tech/voltus/tech_181/techonly.cl/gpdk045.tch

create_rc_corner \
    -name               rc_min \
    -temperature        0 \
    -qrc_tech           ${dataDir}/libs/GPDK045/gsclib045_tech/voltus/tech_181/techonly.cl/gpdk045.tch

##############################################################################
## DELAY CORNERS
##############################################################################
create_delay_corner \
    -name               slow_maxrc \
    -timing_condition   slow \
    -rc_corner          rc_max

create_delay_corner \
    -name               fast_minrc \
    -timing_condition   fast \
    -rc_corner          rc_min

##############################################################################
## CONSTRAINT MODES
##############################################################################
create_constraint_mode \
    -name               func \
    -sdc_files          [list \
                            ${dataDir}/sdc/dtmf_recvr_core_gate.sdc \
                        ]

##############################################################################
## ANALYSIS VIEWS
##############################################################################
create_analysis_view \
    -name               func-slow_maxrc \
    -constraint_mode    func \
    -delay_corner       slow_maxrc

create_analysis_view \
    -name               func-fast_minrc \
    -constraint_mode    func \
    -delay_corner       fast_minrc

##############################################################################
## ACTIVE VIEWS
##############################################################################
set_analysis_view \
    -setup              [list func-slow_maxrc] \
    -hold               [list func-slow_maxrc]
