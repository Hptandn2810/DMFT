# Template for the USF safety flow.
# Cadence Confidential.
# For use with Genus 22.10.


#####################
## Global variables.
#####################
set design dtmf_recvr_core ;
set dataDir "../data" ;
set dbDir dbs ;


###################
## Read Libraries.
###################
read_mmmc ${dataDir}/mmmc_config.tcl ;
read_physical -lefs [list \
                       ${dataDir}/libs/GPDK045/gsclib045/lef/gsclib045_tech.lef \
		       ${dataDir}/libs/GPDK045/gsclib045/lef/gsclib045_macro.lef \
		       ${dataDir}/libs/macros/pllclk.lef \
		       ${dataDir}/libs/macros/ram_256x16A.lef \
		       ${dataDir}/libs/macros/rom_512x16A.lef \
                    ] ;


################
## Read Design.
################
set_db init_hdl_search_path  "${dataDir}/rtl" ;
set rtl_list " \
    pllclk.v \
    accum_stat.v \
    alu_32.v \
    arb.v \
    data_bus_mach.v \
    data_sample_mux.v \
    decode_i.v \
    decoder.v \
    digit_reg.v \
    conv_subreg.v \
    dma.v \
    dtmf_recvr_core.v \
    execute_i.v \
    m16x16.v \
    mult_32_dp.v \
    port_bus_mach.v \
    prog_bus_mach.v \
    results_conv.v \
    spi.v \
    tdsp_core_glue.v \
    tdsp_core_mach.v \
    tdsp_core.v \
    tdsp_data_mux.v \
    tdsp_ds_cs.v \
    test_control.v \
    ulaw_lin_conv.v \
    power_manager.v \
    ram_128x16_test.v \
    ram_256x16_test.v \
"
read_hdl $rtl_list ;
elaborate $design ;

init_design ;
    

##################
## Read floorplan.
##################
read_def ${dataDir}/def/fp.def ;
check_floorplan -detailed ;


###############################
## Create safety island groups.
###############################
#create_group -name master -type fence -rects {230 180 330 330} ;
create_group -name master -floating  ;
update_group -name master -add -objs TDSP_CORE_INST ;

#create_group -name checker -type fence -rects {110 230 210 330} ;
create_group -name checker -floating  ;
update_group -name checker -add -objs RESULTS_CONV_INST ;


create_group -name master1 -floating 
update_group -name master1 -add -objs DMA_INST

create_group -name checker1 -floating
update_group -name checker1 -add -objs ULAW_LIN_CONV_INST


##############################
## Physically aware synthesis.
##############################
set_db auto_ungroup none ; #Preserve logical hierarchy.
syn_generic -physical ;
write_db ${dbDir}/syn_generic.db ;

syn_map -physical ;
write_db ${dbDir}/syn_map.db ;
foreach inst [get_db [get_db insts DMA_INST/breq_reg*] .name] {puts $inst} ; #For every original flop in hinst DMA_INST there are now additional tmr clone flops and voting logic.
write_do_lec -golden rtl -revised fv_map -logfile conformal.rtl_2_fv_map.log > conformal.rtl_2_fv_map.tcl ;

syn_opt -spatial ;
write_db ${dbDir}/syn_opt.db ;
write_netlist > syn_opt.v ;
write_do_lec -golden fv_map -revised ./syn_opt.v -logfile conformal.fv_map_2_syn_opt.log > conformal.fv_map_2_syn_opt.tcl ;


##########################
## db handoff to Innovus.
##########################
write_db -common ${dbDir}/genus_2_innovus.db ;


exit ;
