// Template for the USF safety flow.
// Cadence Confidential.
// For use with Conformal 22.10-s300.


tclmode ;

set_log_file conformal.validate_safety_tmr.log -replace ;
usage -auto -elapse ;

set_dofile_abort off ;


###########################################
# Enable the tmr validation flow.
###########################################
set_usf_option -flow tmr_validation ;

		    
###########################################
# Read the post tmr insertion netlist.
###########################################
set dataDir "../data" ;
read_library -liberty \
                    ${dataDir}/libs/GPDK045/gsclib045/timing/slow_vdd1v2_basicCells.lib \
	            ${dataDir}/libs/macros/ram_256x16A_slow_syn.lib\
                    ${dataDir}/libs/macros/rom_512x16A_slow_syn.lib\
                    ${dataDir}/libs/macros/pllclk_slow.lib ;
read_design ./syn_opt.v -root dtmf_recvr_core -rootonly ;


###########################################
# Read the post tmr insertion USF file.
###########################################
read_usf ./syn_opt.usf ;


###########################################
# Validate the tmr functionality.
###########################################
set_analyze_option -noseq_merge ;
set_x_conversion E -both ;
set_system_mode lec ;

validate_safety_tmr ;

 
exit ;
