# Template for the USF safety flow.
# Cadence Confidential.
# For use with Innovus 22.10.


#####################
## Global variables.
#####################
set design dtmf_recvr_core ;
set dataDir "../data" ;
set dbDir dbs ;


########################################################
## Read the common db from Genus.
## USF is stored in the db. No need to call 'read_usf'.
########################################################
#read_db ${dbDir}/genus_2_innovus.db ;
source ../scripts/dtmf_recvr_core.globals


##################
## Flow settings.
##################
set_db timing_report_fields {timing_point flags arc edge cell fanout load transition incr_delay delay arrival} ;
set_db design_process_node 45 ;
set_db timing_analysis_type ocv ;
set_db timing_analysis_cppr both ;
set_db cts_target_skew 0.20 ;
set_db cts_target_max_transition_time 0.30 ;
set_db cts_inverter_cells {CLKINVX1 CLKINVX2 CLKINVX3 CLKINVX4 CLKINVX6 CLKINVX8 CLKINVX12 CLKINVX16 CLKINVX20} ;
set_db cts_buffer_cells   {CLKBUFX2 CLKBUFX3 CLKBUFX4 CLKBUFX6 CLKBUFX8 CLKBUFX16 CLKBUFX12 CLKBUFX20} ;
set_db design_early_clock_flow true ;

##############################
## Create FP  & pin placement
##############################
create_floorplan -core_density_size 0.7

edit_pin -layer {Metal2 Metal4}   -pin [get_db ports .name] -pin_width 0.5 -pin_depth 4 -offset_start 10  -spacing 2 -edge 0 -spread_type start
#assign_io_pin


##############################
## PG implementation 
##############################
delete_routes -type special
add_stripes -nets {VDD VSS} -layer Metal3 -direction horizontal -width 1.8 -spacing 1.8 -set_to_set_distance 20 -start_from left -switch_layer_over_obs false -max_same_layer_jog_length 2 -use_wire_group 0 -snap_wire_center_to_grid none

add_stripes -nets {VDD VSS} -layer Metal6 -direction vertical  -width 1.8 -spacing 1.8 -set_to_set_distance 20 -start_from left -switch_layer_over_obs false -max_same_layer_jog_length 2 -use_wire_group 0 -snap_wire_center_to_grid none

route_special -connect {block_pin pad_pin pad_ring core_pin floating_stripe} -layer_change_range { Metal1(1) Metal11(11) } -block_pin_target {nearest_target} -pad_pin_port_connect {all_port one_geom} -pad_pin_target {nearest_target} -core_pin_target {first_after_row_end} -floating_stripe_target {block_ring pad_ring ring stripe ring_pin block_pin followpin} -allow_jogging 1 -crossover_via_layer_range { Metal1(1) Metal11(11) } -allow_layer_change 1 -block_pin use_lef -target_via_layer_range { Metal1(1) Metal11(11) }

##############################
## Physical implementation.
##############################
set_db place_global_place_io_pins  true
place_opt_design ;

write_db ${dbDir}/prects.db ;

create_clock_tree_spec
ccopt_design ;
write_db ${dbDir}/cts.db ;

route_design ;
write_db ${dbDir}/route.db ;

opt_design -post_route -setup -hold ;
write_db ${dbDir}/postroute.db ;

#set_multi_cpu_usage -local_cpu 1 -remote_host 1 -cpu_per_remote_host 1 ;
#opt_signoff -all ;
#write_db ${dbDir}/signoff.db ;
#

exit ;
