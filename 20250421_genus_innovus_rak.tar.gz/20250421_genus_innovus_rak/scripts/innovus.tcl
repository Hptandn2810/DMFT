# Template for the USF safety flow.
# Cadence Confidential.
# For use with Innovus 22.10.


#####################
## Global variables.
#####################
set design dtmf_recvr_core ;
set dataDir "../data" ;
set dbDir dbs ;


########################################################
## Read the common db from Genus.
## USF is stored in the db. No need to call 'read_usf'.
########################################################
read_db ${dbDir}/genus_2_innovus.db ;


##################
## Flow settings.
##################
set_db timing_report_fields {timing_point flags arc edge cell fanout load transition incr_delay delay arrival} ;
set_db design_process_node 45 ;
set_db timing_analysis_type ocv ;
set_db timing_analysis_cppr both ;
set_db cts_target_skew 0.20 ;
set_db cts_target_max_transition_time 0.30 ;
set_db cts_inverter_cells {CLKINVX1 CLKINVX2 CLKINVX3 CLKINVX4 CLKINVX6 CLKINVX8 CLKINVX12 CLKINVX16 CLKINVX20} ;
set_db cts_buffer_cells   {CLKBUFX2 CLKBUFX3 CLKBUFX4 CLKBUFX6 CLKBUFX8 CLKBUFX16 CLKBUFX12 CLKBUFX20} ;
set_db design_early_clock_flow true ;


##############################
## Physical implementation.
##############################
place_opt_design ;
write_db ${dbDir}/prects.db ;
gui_highlight {DMA_INST/breq_reg DMA_INST/breq_reg_safety_tmr_clone_0 DMA_INST/breq_reg_safety_tmr_clone_1} -color red ;
gui_clear_highlight ;

ccopt_design ;
write_db ${dbDir}/cts.db ;

route_design ;
write_db ${dbDir}/route.db ;

opt_design -post_route -setup -hold ;
write_db ${dbDir}/postroute.db ;

#set_multi_cpu_usage -local_cpu 1 -remote_host 1 -cpu_per_remote_host 1 ;
#opt_signoff -all ;
#check_safety_mechanism -out_file check_safety_mechanism.rpt ;
#write_db ${dbDir}/signoff.db ;


exit ;
